// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__TRAITS_HPP_
#define CONE_DETECTOR__MSG__DETAIL__CONE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "cone_detector/msg/detail/cone__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'position'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace cone_detector
{

namespace msg
{

inline void to_flow_style_yaml(
  const Cone & msg,
  std::ostream & out)
{
  out << "{";
  // member: label
  {
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << ", ";
  }

  // member: position
  {
    out << "position: ";
    to_flow_style_yaml(msg.position, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Cone & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << "\n";
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position:\n";
    to_block_style_yaml(msg.position, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Cone & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace cone_detector

namespace rosidl_generator_traits
{

[[deprecated("use cone_detector::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const cone_detector::msg::Cone & msg,
  std::ostream & out, size_t indentation = 0)
{
  cone_detector::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use cone_detector::msg::to_yaml() instead")]]
inline std::string to_yaml(const cone_detector::msg::Cone & msg)
{
  return cone_detector::msg::to_yaml(msg);
}

template<>
inline const char * data_type<cone_detector::msg::Cone>()
{
  return "cone_detector::msg::Cone";
}

template<>
inline const char * name<cone_detector::msg::Cone>()
{
  return "cone_detector/msg/Cone";
}

template<>
struct has_fixed_size<cone_detector::msg::Cone>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<cone_detector::msg::Cone>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<cone_detector::msg::Cone>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__TRAITS_HPP_

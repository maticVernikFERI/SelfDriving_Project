// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__BUILDER_HPP_
#define CONE_DETECTOR__MSG__DETAIL__CONE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cone_detector/msg/detail/cone__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cone_detector
{

namespace msg
{

namespace builder
{

class Init_Cone_position
{
public:
  explicit Init_Cone_position(::cone_detector::msg::Cone & msg)
  : msg_(msg)
  {}
  ::cone_detector::msg::Cone position(::cone_detector::msg::Cone::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cone_detector::msg::Cone msg_;
};

class Init_Cone_label
{
public:
  Init_Cone_label()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Cone_position label(::cone_detector::msg::Cone::_label_type arg)
  {
    msg_.label = std::move(arg);
    return Init_Cone_position(msg_);
  }

private:
  ::cone_detector::msg::Cone msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cone_detector::msg::Cone>()
{
  return cone_detector::msg::builder::Init_Cone_label();
}

}  // namespace cone_detector

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__BUILDER_HPP_

// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice
#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define CONE_DETECTOR__MSG__DETAIL__CONE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "cone_detector/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cone_detector
size_t get_serialized_size_cone_detector__msg__Cone(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cone_detector
size_t max_serialized_size_cone_detector__msg__Cone(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cone_detector
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, cone_detector, msg, Cone)();

#ifdef __cplusplus
}
#endif

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_

// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__STRUCT_H_
#define CONE_DETECTOR__MSG__DETAIL__CONE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'label'
#include "rosidl_runtime_c/string.h"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/Cone in the package cone_detector.
typedef struct cone_detector__msg__Cone
{
  rosidl_runtime_c__String label;
  geometry_msgs__msg__Point position;
} cone_detector__msg__Cone;

// Struct for a sequence of cone_detector__msg__Cone.
typedef struct cone_detector__msg__Cone__Sequence
{
  cone_detector__msg__Cone * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cone_detector__msg__Cone__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__STRUCT_H_

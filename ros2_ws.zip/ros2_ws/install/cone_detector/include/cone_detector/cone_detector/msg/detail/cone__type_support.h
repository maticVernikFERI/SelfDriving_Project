// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_H_
#define CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "cone_detector/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_cone_detector
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  cone_detector,
  msg,
  Cone
)();

#ifdef __cplusplus
}
#endif

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_H_

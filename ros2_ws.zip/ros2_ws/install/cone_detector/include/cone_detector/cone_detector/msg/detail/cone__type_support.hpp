// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_HPP_
#define CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "cone_detector/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_cone_detector
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  cone_detector,
  msg,
  Cone
)();
#ifdef __cplusplus
}
#endif

#endif  // CONE_DETECTOR__MSG__DETAIL__CONE__TYPE_SUPPORT_HPP_

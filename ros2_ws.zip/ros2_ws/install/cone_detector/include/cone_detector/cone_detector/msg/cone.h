// generated from rosidl_generator_c/resource/idl.h.em
// with input from cone_detector:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef CONE_DETECTOR__MSG__CONE_H_
#define CONE_DETECTOR__MSG__CONE_H_

#include "cone_detector/msg/detail/cone__struct.h"
#include "cone_detector/msg/detail/cone__functions.h"
#include "cone_detector/msg/detail/cone__type_support.h"

#endif  // CONE_DETECTOR__MSG__CONE_H_

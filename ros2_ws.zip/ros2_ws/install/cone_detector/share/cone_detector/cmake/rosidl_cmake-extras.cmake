# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(cone_detector_IDL_FILES "msg/Cone.idl")
set(cone_detector_INTERFACE_FILES "msg/Cone.msg")

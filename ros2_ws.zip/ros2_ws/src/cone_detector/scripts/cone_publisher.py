#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from cone_detector.msg import Cone
from geometry_msgs.msg import Point

import depthai as dai
from ultralytics import YOLO
import numpy as np

class ConePublisher(Node):
    def __init__(self):
        super().__init__('cone_publisher')
        self.publisher_ = self.create_publisher(Cone, 'cone_detections', 10)

        # Load YOLO model
        self.model = YOLO('/home/ivana/Downloads/best.pt')  # Adjust path if needed

        # Setup pipeline
        pipeline = dai.Pipeline()

        cam = pipeline.create(dai.node.ColorCamera)
        cam.setBoardSocket(dai.CameraBoardSocket.CAM_A)
        cam.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
        cam.setFps(30)

        left = pipeline.create(dai.node.MonoCamera)
        right = pipeline.create(dai.node.MonoCamera)
        stereo = pipeline.create(dai.node.StereoDepth)

        left.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
        right.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
        left.setBoardSocket(dai.CameraBoardSocket.CAM_B)
        right.setBoardSocket(dai.CameraBoardSocket.CAM_C)
        left.out.link(stereo.left)
        right.out.link(stereo.right)

        xout_rgb = pipeline.create(dai.node.XLinkOut)
        xout_depth = pipeline.create(dai.node.XLinkOut)
        xout_rgb.setStreamName("rgb")
        xout_depth.setStreamName("depth")

        cam.video.link(xout_rgb.input)
        stereo.depth.link(xout_depth.input)

        self.device = dai.Device(pipeline)
        self.rgb_queue = self.device.getOutputQueue(name="rgb", maxSize=4, blocking=False)
        self.depth_queue = self.device.getOutputQueue(name="depth", maxSize=4, blocking=False)

        self.timer = self.create_timer(0.5, self.detect_and_publish)

    def detect_and_publish(self):
        print("Running detection...")  # DEBUG print

        in_rgb = self.rgb_queue.get()
        in_depth = self.depth_queue.get()
        frame = in_rgb.getCvFrame()
        depth = in_depth.getFrame()

        results = self.model.predict(frame, verbose=False)
        for det in results[0].boxes:
            x1, y1, x2, y2 = map(int, det.xyxy[0])
            cx_rgb = (x1 + x2) // 2
            cy_rgb = (y1 + y2) // 2

            cx = int(cx_rgb * (depth.shape[1] / frame.shape[1]))
            cy = int(cy_rgb * (depth.shape[0] / frame.shape[0]))

            if cy >= depth.shape[0] or cx >= depth.shape[1]:
                continue

            z = depth[cy, cx].item() / 1000.0
            if z == 0:
                continue

            msg = Cone()
            msg.label = self.model.names[int(det.cls.item())]
            msg.position = Point(x=float(cx_rgb), y=float(cy_rgb), z=float(z))

            print(f"Publishing cone: {msg.label} at x={msg.position.x:.2f}, y={msg.position.y:.2f}, z={msg.position.z:.2f}")  # DEBUG print
            self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = ConePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

